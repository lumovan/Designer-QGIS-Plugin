<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>FiberPlanITDesigner</name>
    <message>
        <location filename="ui_fiberplanitdesigner.py" line="77"/>
        <source>FiberPlanIT Designer Plugin config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_fiberplanitdesigner.py" line="89"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_fiberplanitdesigner.py" line="80"/>
        <source>Executable (with path)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_fiberplanitdesigner.py" line="82"/>
        <source>Path to output folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_fiberplanitdesigner.py" line="85"/>
        <source>Path to input folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_fiberplanitdesigner.py" line="86"/>
        <source>Command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_fiberplanitdesigner.py" line="87"/>
        <source>Output dir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_fiberplanitdesigner.py" line="88"/>
        <source>Input dir</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>fiberplanitdesigner</name>
    <message>
        <location filename="fiberplanitdesigner.py" line="77"/>
        <source>FiberplanIT Designer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fiberplanitdesigner.py" line="105"/>
        <source>Edit Rules</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fiberplanitdesigner.py" line="96"/>
        <source>Configure FiberPlanIT Designer Plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fiberplanitdesigner.py" line="116"/>
        <source>Switch to Area View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fiberplanitdesigner.py" line="124"/>
        <source>Create Trenches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fiberplanitdesigner.py" line="132"/>
        <source>Create Drop Trenches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fiberplanitdesigner.py" line="140"/>
        <source>Process Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fiberplanitdesigner.py" line="150"/>
        <source>Switch to Design View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fiberplanitdesigner.py" line="158"/>
        <source>Calculate Distribution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fiberplanitdesigner.py" line="166"/>
        <source>Lock Clusters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fiberplanitdesigner.py" line="174"/>
        <source>Calculate Network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fiberplanitdesigner.py" line="182"/>
        <source>Show Bill of Material</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fiberplanitdesigner.py" line="233"/>
        <source>Edited layer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fiberplanitdesigner.py" line="233"/>
        <source>There is at least one layer with unsaved edits.
Please save or discard edits first.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fiberplanitdesigner.py" line="270"/>
        <source>FPI returned an error code: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fiberplanitdesigner.py" line="310"/>
        <source>Clusters succesfully locked.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
