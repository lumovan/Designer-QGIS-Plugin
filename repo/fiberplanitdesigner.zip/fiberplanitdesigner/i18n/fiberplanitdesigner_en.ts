<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>FiberPlanITDesigner</name>
    <message>
        <location filename="ui_fiberplanitdesigner.py" line="77"/>
        <source>FiberPlanIT Designer Plugin config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_fiberplanitdesigner.py" line="89"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_fiberplanitdesigner.py" line="80"/>
        <source>Executable (with path)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_fiberplanitdesigner.py" line="82"/>
        <source>Path to output folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_fiberplanitdesigner.py" line="85"/>
        <source>Path to input folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_fiberplanitdesigner.py" line="86"/>
        <source>Command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_fiberplanitdesigner.py" line="87"/>
        <source>Output dir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_fiberplanitdesigner.py" line="88"/>
        <source>Input dir</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
